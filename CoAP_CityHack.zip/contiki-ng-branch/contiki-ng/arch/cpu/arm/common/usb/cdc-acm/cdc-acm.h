#ifndef CDC_ACM_H_UFV6K50827__
#define CDC_ACM_H_UFV6K50827__

void
usb_cdc_acm_setup();

#endif /* CDC_ACM_H_UFV6K50827__ */
